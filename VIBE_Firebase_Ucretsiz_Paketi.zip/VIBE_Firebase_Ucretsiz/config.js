// Firebase Console > Project settings > Your apps > Web app config değerlerini buraya yapıştır.
// Bu dosyada yalnızca web app config bulunur; service account/private key koyma.
window.VIBE_FIREBASE_CONFIG = {
  apiKey: "API_KEY_BURAYA",
  authDomain: "PROJECT_ID.firebaseapp.com",
  projectId: "PROJECT_ID_BURAYA",
  appId: "APP_ID_BURAYA"
};
