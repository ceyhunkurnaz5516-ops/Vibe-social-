# VİBE — Firebase ücretsiz başlangıç paketi

Bu paket önce ücretsiz kalabilecek özelliklerle başlamak üzere hazırlandı: Firebase Authentication + Cloud Firestore ve metin gönderileri. Fotoğraf/video, dosya yükleme yerine HTTPS bağlantısı olarak eklenebilir; Firebase Storage bazı yeni projelerde Blaze faturalandırma planı isteyebildiği için bu pakette dosya yükleme etkin değil.

## Android telefonla kurulum
1. https://console.firebase.google.com/ adresinde proje oluştur.
2. Projeye web uygulaması ekle (</> simgesi). Firebase sana `apiKey`, `authDomain`, `projectId`, `appId` değerleri verir.
3. `config.js` dosyasındaki örnekleri kendi Web App config değerlerinle değiştir.
4. Firebase Console > Authentication > Get started > Sign-in method > Email/Password etkinleştir.
5. Firestore Database > Create database oluştur. Test mode kullanma; `firestore.rules.txt` içindeki kuralları Rules sekmesine yapıştırıp Publish et.
6. `index.html` ve `config.js` dosyalarını HTTPS ile yayınlanan bir statik hosting hizmetine yükle. Yerel dosyaya çift tıklamak gerçek çevrimiçi uygulama olarak çalışması için yeterli değildir.
7. Yayındaki URL'de kayıt, giriş, gönderi ve beğeniyi test et.

## Güvenlik
- Firebase web config, web uygulamasında kullanılan genel yapılandırmadır; service account JSON veya özel anahtar koyma.
- Firestore güvenlik kurallarını yayınlamadan önce incele. Bu temel örnek, tam üretim güvenlik denetimi yerine geçmez.
- Kişisel bilgileri gereksiz yere toplama. Gerçek kullanıma açmadan önce gizlilik politikası, hesap silme, raporlama/engelleme ve moderasyon ekle.
- Ücretsiz kullanım garantisi yoktur; Firebase'in güncel plan ve kota koşullarını kontrol et. Bütçe uyarıları tek başına kesin harcama sınırı değildir.
